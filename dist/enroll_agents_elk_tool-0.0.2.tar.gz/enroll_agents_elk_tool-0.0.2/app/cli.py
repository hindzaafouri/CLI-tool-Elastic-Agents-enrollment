import click
from app.azure_utils import get_credentials, get_compute_client, get_network_client, get_subscription_client, list_subscriptions, list_resource_groups, list_vms, get_vm_ip_and_os_type
from app.elastic_agent import copy_http_ca_to_vm
from azure.mgmt.resource import ResourceManagementClient

@click.group()
def cli():
    pass

@cli.command()
def main():
    try:
        credential = get_credentials()
        subscription_client = get_subscription_client(credential)
        subscriptions = list_subscriptions(subscription_client)

        click.echo("List of Subscriptions:")
        for idx, sub in enumerate(subscriptions, start=1):
            click.echo(f"{idx}. {sub.display_name} ({sub.subscription_id})")

        sub_index = click.prompt("Enter the number of the subscription to use", type=int) - 1
        chosen_subscription = subscriptions[sub_index]
        subscription_id = chosen_subscription.subscription_id
        click.echo(f"Chosen subscription: {chosen_subscription.display_name} ({subscription_id})")

        compute_client = get_compute_client(subscription_id, credential)
        network_client = get_network_client(subscription_id, credential)
        resource_client = ResourceManagementClient(credential, subscription_id)

        rg_list = list_resource_groups(resource_client)

        click.echo("List of Resource Groups:")
        for idx, rg in enumerate(rg_list, start=1):
            click.echo(f"{idx}. {rg.name}")

        rg_index = click.prompt("Enter the number of the resource group to list VMs", type=int) - 1
        chosen_rg = rg_list[rg_index].name
        click.echo(f"Chosen resource group: {chosen_rg}")

        vms = list_vms(compute_client, chosen_rg)

        if vms:
            vm_index = click.prompt("Enter the number of the VM to copy http_ca.crt", type=int) - 1
            selected_vm = vms[vm_index]
            click.echo(f"Copying http_ca.crt to VM '{selected_vm.name}'...")

            vm_name = selected_vm.name
            vm_ip, os_type = get_vm_ip_and_os_type(compute_client, network_client, chosen_rg, vm_name)

            copy_http_ca_to_vm(vm_ip, os_type)

    except Exception as e:
        raise click.ClickException(f"Error: {e}")

if __name__ == "__main__":
    cli()

