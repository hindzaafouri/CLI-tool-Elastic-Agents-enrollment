from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.compute import ComputeManagementClient
from azure.mgmt.network import NetworkManagementClient
from azure.mgmt.subscription import SubscriptionClient
import click

def get_credentials():
    try:
        credential = DefaultAzureCredential()
        return credential
    except Exception as e:
        raise click.ClickException(f"Failed to retrieve Azure credentials: {e}")

def get_compute_client(subscription_id, credential):
    return ComputeManagementClient(credential, subscription_id)

def get_network_client(subscription_id, credential):
    return NetworkManagementClient(credential, subscription_id)

def get_subscription_client(credential):
    return SubscriptionClient(credential)

def list_subscriptions(subscription_client):
    return list(subscription_client.subscriptions.list())

def list_resource_groups(resource_client):
    return list(resource_client.resource_groups.list())

def list_vms(compute_client, resource_group_name):
    try:
        vm_list = compute_client.virtual_machines.list(resource_group_name)
        vms = list(vm_list)
        if not vms:
            raise click.ClickException(f"No VMs found in resource group '{resource_group_name}'")
        return vms
    except Exception as e:
        raise click.ClickException(f"Error listing VMs in resource group '{resource_group_name}': {e}")

def get_vm_ip_and_os_type(compute_client, network_client, resource_group_name, vm_name):
    vm = compute_client.virtual_machines.get(resource_group_name, vm_name)
    os_type = vm.storage_profile.os_disk.os_type
    network_interface_id = vm.network_profile.network_interfaces[0].id
    interface_name = network_interface_id.split('/')[-1]
    sub_id = network_interface_id.split('/')[4]
    network_interface = network_client.network_interfaces.get(sub_id, interface_name)
    private_ip = network_interface.ip_configurations[0].private_ip_address
    return private_ip, os_type

