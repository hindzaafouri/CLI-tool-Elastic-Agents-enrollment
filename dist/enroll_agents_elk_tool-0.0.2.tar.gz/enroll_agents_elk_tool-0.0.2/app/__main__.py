# enroll_agents_elk_tool/__main__.py
from .install_agents import main

if __name__ == '__main__':
    main()

